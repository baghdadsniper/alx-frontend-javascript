<h2>0x01. ES6 Promises</h2>

<h3>Learning Objectives</h3>

<ol>
    <li>Promises (how, why, and what)</li>
    <li>How to use the then, resolve, catch methods</li>
    <li>How to use every method of the Promise object</li>
    <li>Throw / Try</li>
    <li>How to use an async function</li> 
    <li>The await operator</li>   
</ol>

