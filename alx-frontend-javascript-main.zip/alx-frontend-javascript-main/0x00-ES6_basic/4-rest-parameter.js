export default function returnHowManyArguments(...manyArgs) {
  return manyArgs.length;
}
