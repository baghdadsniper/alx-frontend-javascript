import getBudgetObject from './7-getBudgetObject.js';

console.log(getBudgetObject(400, 700, 900));
