import initializeRooms from './1-make_classrooms.js';

console.log(initializeRooms());
