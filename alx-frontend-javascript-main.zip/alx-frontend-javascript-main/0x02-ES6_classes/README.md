<h2>0x02. ES6 classes</h2>

<h3>Learning Objectives</h3>

<ol>
    <li>How to define a Class</li>
    <li>How to add methods to a class</li>
    <li>Why and how to add a static method to a class</li>
    <li>How to extend a class from another</li>
    <li>Metaprogramming and symbols</li>    
</ol>
