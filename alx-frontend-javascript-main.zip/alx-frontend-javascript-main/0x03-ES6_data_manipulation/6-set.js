export default function setFromArray(arr) {
  return new Set(arr);
}
