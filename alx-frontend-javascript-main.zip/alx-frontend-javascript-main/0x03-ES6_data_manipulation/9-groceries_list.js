export default function groceriesList() {
  const shoppingList = new Map([
    ['Apples', 10],
    ['Tomatoes', 10],
    ['Pasts', 1],
    ['Rice', 1],
    ['Banana', 5],
  ]);
  return shoppingList;
}
